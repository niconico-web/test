const BossManager = require('../managers/BossManager');

module.exports = function (io) {
    io.on('connection', (socket) => {
        // �N���C�A���g����̃{�X���X�g�v���ɉ���
        socket.on('bosses:get', () => {
            try {
                const bosses = BossManager.getAllBosses();
                socket.emit('bosses:list', bosses);
            } catch (e) {
                console.error("Error getting boss list:", e);
                socket.emit('dataError', 'Failed to get boss list.');
            }
        });

        // �N���C�A���g����̓���{�X�f�[�^�v���ɉ���
        socket.on('bosses:getDetails', ({ bossId, difficulty }) => {
            try {
                const boss = BossManager.createBossForBattle(bossId, difficulty);
                if (!boss) {
                    socket.emit('dataError', 'Invalid boss selection.');
                    return;
                }
                socket.emit('bosses:details', { boss });
            } catch (e) {
                console.error(`Error creating boss for battle (id: ${bossId}, diff: ${difficulty}):`, e);
                socket.emit('dataError', 'Failed to create boss for battle.');
            }
        });
    });
};